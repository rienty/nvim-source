# Tree-sitter VimL parser

A parser for VimL using treesitter.

Any contribution is greatly appreciated, so please look [here](CONTRIBUTING.md) for more information.
__Don't forget that reporting and issue is already a contribution, and will greatly help, so please do report issues!__
